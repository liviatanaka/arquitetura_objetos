package com.entregas.rede;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedeApplication.class, args);
	}

}
